#!/usr/bin/env python
# coding: utf-8

# In[101]:


#Import the necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
#! pip install reportlab
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.units import inch
from reportlab.lib import colors
from datetime import datetime, timedelta
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.acroform import AcroForm
from reportlab.platypus import Table, TableStyle
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.barcharts import HorizontalBarChart
import warnings


# In[3]:


#Define a function to get the previous month and year
def get_previous_month():
    now = datetime.now()
    previous_month = now.month - 1 if now.month > 1 else 12
    previous_year = now.year if now.month > 1 else now.year - 1
    return previous_month, previous_year


# In[45]:


csat_score = input("Enter CSAT Score: ")
association_rate = input("Enter Association Rate: ")


# In[105]:


# Set the page size to PowerPoint slide size (10 inches by 7 inches)
slide_size = landscape((10 * inch, 7 * inch))

#Create a PDF file and set the canvas
pdf = canvas.Canvas("governance_report.pdf", pagesize=slide_size)
width, height = slide_size

#Create the Title Page (Page 1)

# Set the background color to blue
pdf.setFillColor(colors.navy)
pdf.rect(0, 0, width, height, fill=True)
# Set the text color to white
pdf.setFillColor(colors.white)

# Set the font and font size
pdf.setFont("Times-Bold", 20)
pdf.drawCentredString(140, height / 2 + 200, "Northwestern Mutual")

# Set the font and font size
pdf.setFont("Times-Bold", 20)
pdf.drawCentredString(190, height / 2 + 50, "TeamName Support Governance")
pdf.line(50, height / 2 + 43, 350, height / 2 + 43)

pdf.setFont("Times-Roman", 16)
previous_month, previous_year = get_previous_month()
pdf.drawString(50, (height / 2) + 20 , f"Previous Month: {previous_month} {previous_year}")
pdf.drawString(50, (height / 2) , f"Current Year: {datetime.now().year}")

pdf.setFont("Times-Roman", 10)
pdf.drawString(50, height / 2 - 200, "The Northwestern Mutal Life Insurance Company - Milwaukee, WI")

#Create Page 2
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(130, 450, "Page 2: Incident Metrics")
pdf.line(50, 445, width-50, 445)

# draw a rectangle
#pdf.rect(480, 300, 190, 140, stroke=1, fill=1)

# Define the position and size of the input box
input_box_x = 530  # X-coordinate of the input box
input_box_y = 370  # Y-coordinate of the input box
input_box_width = 100  # Width of the input box
input_box_height = 30  # Height of the input box

# Create the text field
pdf.setFont("Times-Roman", 14)
pdf.setFillColor(colors.black)
pdf.drawCentredString(580, 405, "CSAT%")

#input box
# Set the background color
pdf.setFillColor(colors.lightblue)
pdf.rect(input_box_x, input_box_y, input_box_width, input_box_height, stroke=False, fill=True)

# Add text
pdf.setFillColor(colors.black)
pdf.drawString(input_box_x + 40, input_box_y + 10, f"{float(csat_score):.0%}")

# Define the position and size of the input box
input_box_x1 = 530  # X-coordinate of the input box
input_box_y1 = 300  # Y-coordinate of the input box
input_box_width1 = 100  # Width of the input box
input_box_height1 = 30  # Height of the input box

# Create the text field
pdf.setFont("Times-Roman", 14)
pdf.setFillColor(colors.black)
pdf.drawCentredString(580, 335, "Association Rate")

#input box
# Set the background color
pdf.setFillColor(colors.lightblue) 
pdf.rect(input_box_x1, input_box_y1, input_box_width1, input_box_height1, stroke=False, fill=True)

# add text
pdf.setFillColor(colors.black)
pdf.drawString(input_box_x1 +40, input_box_y1+10, f"{float(association_rate):.0%}")


import glob
from pathlib import Path

# Define the path to the directory containing the CSV files
directory_path = 'report-dataset-files/'

# Get a list of all CSV files in the directory
csv_files = Path(directory_path).glob('*.csv')

# Create an empty list to store the data from each CSV file
dataframes = []

# Iterate over each CSV file
for file in csv_files:
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(file)
    # Append the DataFrame to the list
    dataframes.append(df)
    
data = dataframes[5]
data = data.drop('inc_assignment_group', axis=1)
PreMnth_CurrtYr = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [95,110,110,110]  

pdf.drawCentredString(130, 425, "PreviousMonth CurrentYear")
# Create the table from the data
t = Table(PreMnth_CurrtYr,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 8),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), "#FFFFFF"),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 10),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 370) # table at right side


data = dataframes[0]
# Renaming the variables
data = data.rename(columns={'Total Available Minutes': 'Total Available \n Minutes',
                                       'Operational Outage Minutes': 'Operational Outage \n Minutes'})

Application_Avail = [list(data.columns)] + data.values.tolist()

data1 = dataframes[1].head(4)
# Renaming the variables
data1 = data1.rename(columns={'Date/Time App Went Down' : 'Date/Time App \n Went Down',
                              'Date/Time App Came Back' : 'Date/Time App \n Came Back',
                              'Operational Outage Minutes' : 'Operational \n Outage Minutes',
                              'Date App Wentdown' : 'Date App \n Wentdown',
                              'Feature Name' : 'Feature \n Name',
                              'Feature Weight' : 'Feature \n Weight',
                              'INC Number' : 'INC \n Number',
                              'Operational Adjustment' : 'Operational \n Adjustment',
                              'Outage Minutes' : 'Outage \n Minutes',
                              'Date App Wentdown' : 'Date App \n Wentdown'})
Application_FeatureOutage = [list(data1.columns)] + data1.values.tolist()

data2 = dataframes[2]
data2 = data2.rename(columns={'Date/Time App Went Down' : 'Date/Time App \n Went Down',
                              'Date/Time App Came Back' : 'Date/Time App \n Came Back',
                              'Operational Outage Minutes' : 'Operational \n Outage Minutes',
                              'INC Number':'INC \n Number',
                              'Date App Went Down' : 'Date App \n Went Down'})
Application_Outage = [list(data2.columns)] + data2.values.tolist()


# Set the width for each column
column_widths = [125,100,100,100]  

pdf.drawCentredString(120, 350, "Application Availability")
# Create the table from the data
t = Table(Application_Avail,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 8),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 10),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), "#FFFFFF"),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 5),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 290) 

# Create the table 2 from the data
pdf.drawCentredString(105, 270, "Application Outage")
column_widths1 = [100, 65, 75, 75, 115, 115, 90]
t1 = Table(Application_Outage,
         colWidths=column_widths1)

# Apply the table style to table
t1.setStyle(table_style)

t1.wrapOn(pdf, width, height)     
t1.drawOn(pdf,50, 170) 

# Create the table 3 from the data
pdf.drawCentredString(127, 150, "Application Feature Outage")
column_widths2 = [75, 50, 60, 60, 75, 75, 50, 70, 50, 70]
t2 = Table(Application_FeatureOutage,
         colWidths=column_widths2)

# Apply the table style to the table
t2.setStyle(table_style)

t2.wrapOn(pdf, width, height)     
t2.drawOn(pdf,50, 30) 

#Create Page 3 (Pie chart and horizontal bar charts)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(165, 450, "Page 3: Incident Metrics-Continued")
pdf.line(50, 445, width-50, 445)

pie = dataframes[3]['business_service'].value_counts()
data = pie.values.tolist()
lable = pie.index.values.tolist()

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(140, 400, " Incident by Service")
# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a pie chart
pc = Pie()
pc.x = 20
pc.y = 100
pc.width = 150
pc.height = 180
pc.data = data
#pc.labels = lable
pc.sideLabels = False
pc.simpleLabels = 0
pc.slices.strokeWidth = 0.5

# Create a legend
legend = Legend()
legend.x = 40
legend.y = 50
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 4  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(pc.slices[i].fillColor, lable[i]) for i in range(len(pc.data))]

# Add the pie chart and legend to the drawing
d.add(pc)
d.add(legend)

d.wrapOn(pdf, width, height)     
d.drawOn(pdf,40,100) 


data = dataframes[3].groupby(['priority', 'business_service']).size().unstack()
data = data.fillna(0)

# Extract data and labels from the DataFrame
data1 = data.iloc[0,:].values.tolist()
data2 = data.iloc[1,:].values.tolist()
label = data.columns.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(390, 430, "Open Incident by Priority")
# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 65
bc.y = 170
bc.width = 120
bc.height = 150
bc.data = [data1, data2]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 7
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1) + max(data2)  # Set the maximum value based on the maximum values of both variables
bc.bars[0].fillColor = colors.blue  # Set the color for variable1 bars
bc.bars[1].fillColor = colors.red  # Set the color for variable2 bars
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Create a legend
legend = Legend()
legend.x = 180
legend.y = 140
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(colors.blue, labels[0]), (colors.red, labels[1])]

# Add the bar chart and legend to the drawing
d.add(bc)
d.add(legend)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 100)


# Removing rows with missing values from variable 'resolved_at'
df = dataframes[3].dropna(subset=['resolved_at'])
data = df.groupby(['priority', 'business_service']).size().unstack()
data = data.fillna(0)

# Extract data and labels from the DataFrame
data1 = data.iloc[0,:].values.tolist()
data2 = data.iloc[1,:].values.tolist()
label = data.columns.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(610, 430, "Resolved Incident by Priority")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 260
bc.y = 170
bc.width = 120
bc.height = 150
bc.data = [data1, data2]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 7
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1) + max(data2)  # Set the maximum value based on the maximum values of both variables
bc.bars[0].fillColor = colors.blue  # Set the color for variable1 bars
bc.bars[1].fillColor = colors.red  # Set the color for variable2 bars
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 300, 100)


data = dataframes[3].groupby(['business_service', 'u_incident_type']).size().unstack()
data = data.fillna(0)

# Extract data and labels from the DataFrame
data1 = data.iloc[0,:].values.tolist()
data2 = data.iloc[1,:].values.tolist()
data3 = data.iloc[2,:].values.tolist()
data4 = data.iloc[3,:].values.tolist()
label = data.columns.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(500, 210, "Incident by Type")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 60
bc.y = 30
bc.width = 310
bc.height = 140
bc.data = [data1, data2, data3, data4]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1) + max(data2)  # Set the maximum value based on the maximum values of both variables
bc.bars[0].fillColor = colors.violet # Set the color for variable1 bars
bc.bars[1].fillColor = colors.orange  # Set the color for variable2 bars
bc.bars[2].fillColor = colors.green  # Set the color for variable3 bars
bc.bars[3].fillColor = colors.yellow  # Set the color for variable4 bars
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels

# Create a legend
legend = Legend()
legend.x = -30
legend.y = 5
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 5  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 3  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(colors.violet, labels[0]), (colors.orange, labels[1]),(colors.green, labels[2]), (colors.yellow, labels[3])]

# Add the bar chart and legend to the drawing
d.add(bc)
d.add(legend)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)

#Create Page 4 (Horizontal Bar Chart)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(130, 450, "Page 4: Problem Metrics")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].groupby(['business_service']).count()['sys_created_on']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(160, 270, "Opened Problem")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 50
bc.y = 200
bc.width = 150
bc.height = 130
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels


# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 50, 100)

data = dataframes[4].groupby(['business_service']).count()['resolved_at']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(380, 270, "Resolved Problem")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 200
bc.y = 200
bc.width = 150
bc.height = 130
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 110, 100)


data = dataframes[4].groupby(['number' ,'business_service']).sum('related_incidents').sort_values('related_incidents', ascending=False).head(10).reset_index()

# Extract data and labels from the DataFrame
data1 = data.iloc[:,2].values.tolist()
label = data.iloc[:,0].values.tolist()
labels = data['business_service'].unique().tolist()

pdf.setFont("Times-Roman", 10)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(290, 240, "Top Problems with Linked Incidents")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 90
bc.y = 30
bc.width = 350
bc.height = 170
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

colors_list = []
variable = data['business_service']  # Replace 'your_variable' with the name of your variable
for value in variable:
    if value == 'Illustrations':
        bc.bars[0].fillColor=colors.blue  # Set the color for category1
    elif value == 'Network Illustration System':
        bc.bars[0].fillColor=colors.red  # Set the color for category2
    else:
        bc.bars[0].fillColor=colors.gray  # Set the default color for other categories

#bc.bars.fillColor = colors_list

# Create a legend
legend = Legend()
legend.x = 100
legend.y = 10
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(bc.bars[i].fillColor, labels[i]) for i in range(len(labels))]
# Add the bar chart and legend to the drawing
d.add(bc)
# Add a legend to the drawing
d.add(legend)


# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 10, 30)

data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)

#Create Page 5 (Active Problems by Service [NGIS/AMI]t)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(185, 450, "Page 5: Problem Overview – NGIS | AMI")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].loc[(dataframes[4]['active']== True) & (dataframes[4]['business_service']== 'Illustrations')]
data = data[['number','business_service','related_incidents','u_jira_ticket','problem_state','sys_created_on','priority']]

data = data.rename(columns={'business_service' : 'service',
                            'related_incidents' : 'related \n incidents',
                            'u_jira_ticket' : 'u_jira \n ticket',
                            'problem_state' : 'problem state', 
                            'sys_created_on' : 'opened',
                              })

data = data.head(15)
data = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [60,50,50,50,100,70,50]  

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.black)
pdf.drawCentredString(150, 425, "Active Problems by Service [NGIS/AMI]")
# Create the table from the data
t = Table(data,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 10),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), colors.lightblue),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 100) # table at right side


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


#Create Page 6 (Active Problems by Service [NIS/EB/QE/IFRP])
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(212, 450, "Page 6: Problem Overview – NIS | EB | QE | IFRP")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].loc[(dataframes[4]['active']== True) & (dataframes[4]['business_service'] != 'Illustrations')]
data = data[['number','business_service','related_incidents','u_jira_ticket','problem_state','sys_created_on','priority']]

data = data.rename(columns={'business_service' : 'service',
                            'related_incidents' : 'related \n incidents',
                            'u_jira_ticket' : 'u_jira \n ticket',
                            'problem_state' : 'problem state', 
                            'sys_created_on' : 'opened',
                              })

data = data.head(15)
data = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [70,80,40,40,85,65,50]  

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.black)
pdf.drawCentredString(167, 425, "Active Problems by Service [NIS/EB/QE/IFRP]")
# Create the table from the data
t = Table(data,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 10),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), colors.lightblue),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 150) # table at right side


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)

#Create Page 7 (Problem Overview)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(140, 450, "Page 7: Problem Overview")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].groupby(['priority']).count()['sys_created_on']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(330, 410, "PX Open Problems by Priority")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = VerticalBarChart()
bc.x = 70
bc.y = 50
bc.width = 450
bc.height = 300
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 14
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 14  # Set the font size of the bar labels
#bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 70, 30)

#Create Page 8 (2023 Support Initiatives & Goals)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(185, 450, "Page 8: 2023 Support Initiatives & Goals")
pdf.line(50, 445, width-50, 445)

# Save and close the PDF
#pdf_form.updatePageFormFieldValues(pdf)
pdf.save()

