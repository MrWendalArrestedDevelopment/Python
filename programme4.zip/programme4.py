#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Import the necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().system(' pip install reportlab')
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib import utils

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.acroform import AcroForm

from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.barcharts import HorizontalBarChart

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

from reportlab.pdfgen import canvas

get_ipython().system('pip install PyPDF2')
from PyPDF2 import PdfWriter, PdfReader

import warnings
warnings.filterwarnings("ignore")

import calendar
from datetime import datetime, timedelta
import glob
from pathlib import Path


# In[2]:


#Define a function to get the previous month and year
def get_previous_month():
    now = datetime.now()
    previous_month = now.month - 1 if now.month > 1 else 12
    previous_year = now.year if now.month > 1 else now.year - 1
    return previous_month, previous_year


# In[3]:


# Utility function to break a list into multiple list of lists with at most 15 elements
def get_multilist_data(my_list):
    # First element is used as header so its removed and later added to each new list
    first_element = my_list[0]
    my_list.pop(0)
    
    #Number of elemets per list/ rows per table
    n = 15            
    
    new_list = [my_list[i:i+n] for i in range(0, len(my_list), n)]
    
    #Adding the table header to each new list
    for i in range(len(new_list)):
        new_list[i].insert(0,first_element)
    return new_list
    


# In[4]:


# Function to create new table on a new page
def new_table_page(data,col_width,table_style,header_string):
    pdf.showPage()
    previously_taken_space = 50
    
    # Set data for table
    t2 = Table(data,colWidths=col_width)

    # Apply the table style to the table
    t2.setStyle(table_style)

    # Calculating displacement from top
    row_space = len(data) * 23 # number of row * space per row
    total_space_taken = row_space + previously_taken_space
    
    # Add title for table
    pdf.drawString(50, 504 - 40 ,header_string)
    
    t2.wrapOn(pdf, width, height)     
    t2.drawOn(pdf,50, 504 - total_space_taken) 


# In[5]:


csat_score = input("Enter CSAT Score: ")
association_rate = input("Enter Association Rate: ")
#csat_score = 25
#association_rate = 50


# In[6]:


# Set the page size to PowerPoint slide size (10 inches by 7 inches)
slide_size = landscape((10 * inch, 7 * inch))

#Create a PDF file and set the canvas
pdf = canvas.Canvas("governance_report.pdf", pagesize=slide_size)
width, height = slide_size

#Create the Title Page (Page 1)

# Set the background color to blue
pdf.setFillColor(HexColor(0x0e497b))
pdf.rect(0, 0, width, height, fill=True)
# Set the text color to white
pdf.setFillColor(colors.white)

# Set the font and font size
pdf.setFont("Times-Bold", 20)
pdf.drawCentredString(140, height / 2 + 200, "Northwestern Mutual")

# Set the font and font size
pdf.setFont("Times-Bold", 20)
pdf.drawCentredString(190, height / 2 + 50, "TeamName Support Governance")
pdf.line(50, height / 2 + 43, 350, height / 2 + 43)

pdf.setFont("Times-Roman", 16)
previous_month, previous_year = get_previous_month()
pdf.drawString(50, (height / 2) + 20 , f"Previous Month: {previous_month} {previous_year}")
pdf.drawString(50, (height / 2) , f"Current Year: {datetime.now().year}")

pdf.setFont("Times-Roman", 10)
pdf.drawString(50, height / 2 - 200, "The Northwestern Mutal Life Insurance Company - Milwaukee, WI")


# In[7]:


#Create Page 2
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(130, 450, "Part 1: Incident Metrics")
pdf.line(50, 445, width-50, 445)

# Define the position and size of the input box
input_box_x = 530  # X-coordinate of the input box
input_box_y = 370  # Y-coordinate of the input box
input_box_width = 100  # Width of the input box
input_box_height = 30  # Height of the input box

# Create the text field
pdf.setFont("Times-Roman", 14)
pdf.setFillColor(colors.black)
pdf.drawCentredString(580, 405, "CSAT%")

#input box
# Set the background color
pdf.setFillColor(colors.lightblue)
pdf.rect(input_box_x, input_box_y, input_box_width, input_box_height, stroke=False, fill=True)

# Add text
pdf.setFillColor(colors.black)
pdf.drawString(input_box_x + 30, input_box_y + 10, f"{float(csat_score)}"+"%")

# Box around text
pdf.setStrokeColorRGB(0.5, 0.1, 0.1)
pdf.rect(input_box_x, input_box_y, input_box_width, input_box_height)


# Define the position and size of the input box
input_box_x1 = 530  # X-coordinate of the input box
input_box_y1 = 300  # Y-coordinate of the input box
input_box_width1 = 100  # Width of the input box
input_box_height1 = 30  # Height of the input box

# Create the text field
pdf.setFont("Times-Roman", 14)
pdf.setFillColor(colors.black)
pdf.drawCentredString(580, 335, "Association Rate")

#input box
# Set the background color
pdf.setFillColor(colors.lightblue) 
pdf.rect(input_box_x1, input_box_y1, input_box_width1, input_box_height1, stroke=False, fill=True)

# add text
pdf.setFillColor(colors.black)
pdf.drawString(input_box_x1 +30, input_box_y1+10, f"{round(float(association_rate),0)}"+"%")

# Box around text
pdf.setStrokeColorRGB(0.5, 0.1, 0.1)
pdf.rect(input_box_x1, input_box_y1, input_box_width1, input_box_height1)

# Define the path to the directory containing the CSV files
directory_path = 'report-dataset-files/'

# Get a list of all CSV files in the directory
csv_files = Path(directory_path).glob('*.csv')

# Create an empty list to store the data from each CSV file
dataframes = []

# Iterate over each CSV file
for file in csv_files:
    # Read the CSV file into a pandas DataFrame
    df = pd.read_csv(file)
    # Append the DataFrame to the list
    dataframes.append(df)
    
data = dataframes[5]
data = data.drop('inc_assignment_group', axis=1)
PreMnth_CurrtYr = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [95,110,110,110]  

# Previous month current year string
pdf.drawCentredString(80, 425, f"{calendar.month_name[previous_month]},{datetime.now().year}")

# Create the table from the data
t = Table(PreMnth_CurrtYr,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 8),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), "#FFFFFF"),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 10),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])
# Calculating displacement from top
previously_taken_space = 100
row_space = len(PreMnth_CurrtYr) * 20 # number of row * space per row

total_space_taken = row_space + previously_taken_space

# Apply the table style to the table
t.setStyle(table_style)

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 500-total_space_taken) # table at right side

# Updating previously taken space to indicate the end of usable space
previously_taken_space = 500-(total_space_taken+1) 


# In[8]:


# New data for tables
data = dataframes[0]
# Renaming the variables
data = data.rename(columns={'Total Available Minutes': 'Total Available \n Minutes',
                                       'Operational Outage Minutes': 'Operational Outage \n Minutes'})

Application_Avail = [list(data.columns)] + data.values.tolist()

data1 = dataframes[1].head(4)
# Renaming the variables
data1 = data1.rename(columns={'Date/Time App Went Down' : 'Date/Time App \n Went Down',
                              'Date/Time App Came Back' : 'Date/Time App \n Came Back',
                              'Operational Outage Minutes' : 'Operational \n Outage Minutes',
                              'Date App Wentdown' : 'Date App \n Wentdown',
                              'Feature Name' : 'Feature \n Name',
                              'Feature Weight' : 'Feature \n Weight',
                              'INC Number' : 'INC \n Number',
                              'Operational Adjustment' : 'Operational \n Adjustment',
                              'Outage Minutes' : 'Outage \n Minutes',
                              'Date App Wentdown' : 'Date App \n Wentdown'})
Application_FeatureOutage = [list(data1.columns)] + data1.values.tolist()

data2 = dataframes[2]
data2 = data2.rename(columns={'Date/Time App Went Down' : 'Date/Time App \n Went Down',
                              'Date/Time App Came Back' : 'Date/Time App \n Came Back',
                              'Operational Outage Minutes' : 'Operational \n Outage Minutes',
                              'INC Number':'INC \n Number',
                              'Date App Went Down' : 'Date App \n Went Down'})
Application_Outage = [list(data2.columns)] + data2.values.tolist()

# Define the style for the tables (Application Availability , Feature , Outage)
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 8),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 10),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), "#FFFFFF"),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 5),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])


# In[9]:


# Dynamic Table 1 (Application Availability)
all_table_data = get_multilist_data(Application_Avail)

column_widths = [200,135,135,135] # For "Application Outage" table

for data in all_table_data:
    new_table_page(data,column_widths,table_style,"Application Availability")


# In[10]:


# Dynamic Table 2 (Application outage)
all_table_data = get_multilist_data(Application_Outage)

column_widths1 = [100, 65, 75, 75, 115, 115, 90] # For "Application Outage" table

for data in all_table_data:
    new_table_page(data,column_widths1,table_style,"Application Outage")


# In[11]:


# Dynamic Table 3 (Application Feature Outage)

all_table_data = get_multilist_data(Application_FeatureOutage)
#display(all_table_data)

column_widths2 = [75, 50, 60, 60, 75, 75, 50, 70, 50, 70] # For Application Feature Outage table

for data in all_table_data:
    new_table_page(data,column_widths2,table_style,"Application Feature Outage")


# In[12]:


#Create Page 3 (Pie chart and horizontal bar charts)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(165, 450, "Part 2: Incident Metrics-Continued")
pdf.line(50, 445, width-50, 445)

pie = dataframes[3]['business_service'].value_counts()
data = pie.values.tolist()
lable = pie.index.values.tolist()
# changing lables to include counts and percantages in the lables
new_lable_list = []
for val_l,val_d in zip(lable,data):
    percentage = (val_d/sum(data))*100.00
    new_lable = f"{val_l} - count:{val_d} ({percentage:.2f}%)"
    new_lable_list.append(new_lable)
#assigning lables with count and percentage
lable = new_lable_list

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(140, 400, " Incident by Service")
# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a pie chart
pc = Pie()
pc.x = 20
pc.y = 100
pc.width = 150
pc.height = 180
pc.data = data
#pc.labels = lable
pc.sideLabels = True
pc.simpleLabels = 0
pc.slices.strokeWidth = 0.5

# Create a legend
legend = Legend()
legend.x = 40
legend.y = 50
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = len(lable)  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(pc.slices[i].fillColor, lable[i]) for i in range(len(pc.data))]

# Add the pie chart and legend to the drawing
d.add(pc)
d.add(legend)

d.wrapOn(pdf, width, height)     
d.drawOn(pdf,40,100) 

# Read data For bar charts "Open incident by priority" and "Resolved incident by priority"
data = dataframes[3].groupby(['priority', 'business_service']).size().unstack()
data = data.fillna(0)

# Extract data and labels from the DataFrame
data_extract = []
for i in range(data.shape[0]):                 #for number of rows
    new_data = data.iloc[i,:].values.tolist()
    data_extract.append(new_data)    

label = data.columns.values.tolist()
labels = data.index.values.tolist()


pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(390, 430, "Open Incident by Priority")
# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 65
bc.y = 170
bc.width = 120
bc.height = 150
bc.data = data_extract

#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 7
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = sum(max(sublist) for sublist in data_extract)  # Set the maximum value based on the maximum values of both variables

#set color for each bar
color_list = [colors.blue,colors.red,colors.green,colors.yellow,colors.purple] #list of color to choose from
for i in range(len(labels)):
    bc.bars[i].fillColor = color_list[i%len(color_list)]  # Set the color for ith bar (modulas to re-use color)

bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Create a legend
legend = Legend()
legend.x = 50
legend.y = 140
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items

# Create color name pairs in legend
total_color_pairs = []
for i in range(len(labels)):
    color_pair = (color_list[i%len(color_list)],labels[i])
    total_color_pairs.append(color_pair)
    
legend.colorNamePairs = total_color_pairs

# Add the bar chart and legend to the drawing
d.add(bc)
d.add(legend)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 100)


# Removing rows with missing values from variable 'resolved_at'
df = dataframes[3].dropna(subset=['resolved_at'])
data = df.groupby(['priority', 'business_service']).size().unstack()
data = data.fillna(0)

# Extract data and labels from the DataFrame

data1 = data.iloc[0,:].values.tolist()
data2 = data.iloc[1,:].values.tolist()
label = data.columns.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(610, 430, "Resolved Incident by Priority")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 260
bc.y = 170
bc.width = 120
bc.height = 150
bc.data = [data1, data2]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 7

bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1) + max(data2)  # Set the maximum value based on the maximum values of both variables
bc.bars[0].fillColor = colors.blue  # Set the color for variable1 bars
bc.bars[1].fillColor = colors.red  # Set the color for variable2 bars
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 300, 100)

data = dataframes[3].groupby(['business_service', 'u_incident_type']).size().unstack()
data = data.fillna(0)
    
# Extract data and labels from the DataFrame
# Extract data and labels from the DataFrame
data_extract = []
for i in range(data.shape[0]):                 #for number of rows
    new_data = data.iloc[i,:].values.tolist()
    data_extract.append(new_data)   

label = data.columns.values.tolist()
labels = data.index.values.tolist()

for sublist in data_extract:
    for i, value in enumerate(sublist):
        if value == 0:
            sublist[i] = None

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(500, 210, "Incident by Type")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 60
bc.y = 30
bc.width = 330
bc.height = 140
bc.data = data_extract

#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.0 

bc.categoryAxis.style = 'stacked'   # for stacked style barchart
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 8

bc.valueAxis.valueMin = 0

# Set the maximum value based on the maximum values of both variables
bc.valueAxis.valueMax = sum(max(i for i in sublist if i is not None) for sublist in data_extract)  

#set color for each bar
color_list = [colors.violet,colors.orange,colors.green,colors.yellow,colors.purple] #list of color to choose from
for i in range(len(labels)):
    bc.bars[i].fillColor = color_list[i%len(color_list)]  # Set the color for ith bar (modulas to re-use color)

bc.barLabels.nudge = -7 #trg # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars'
bc.barLabelFormat = '%d'
bc.barLabels.fontSize = 7  # Set the font size of the bar labels

# Create a legend
legend = Legend()
legend.x = -20
legend.y = 5
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 5  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 2  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(colors.violet, labels[0]), (colors.orange, labels[1]),(colors.green, labels[2]), (colors.yellow, labels[3])]

# Add the bar chart and legend to the drawing
d.add(bc)
d.add(legend)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)

display(bc.data)


# In[13]:


#Create Page 4 (Horizontal Bar Chart)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(130, 450, "Part 3: Problem Metrics")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].groupby(['business_service']).count()['sys_created_on']
# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(160, 270, "Opened Problem")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 50
bc.y = 200
bc.width = 150
bc.height = 130
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels


# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 50, 100)

data = dataframes[4].groupby(['business_service']).count()['resolved_at']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(380, 270, "Resolved Problem")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 200
bc.y = 200
bc.width = 150
bc.height = 130
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 110, 100)


data = dataframes[4].groupby(['number' ,'business_service']).sum('related_incidents').sort_values('related_incidents', ascending=False).head(10).reset_index()
data = data.sort_values('related_incidents',ascending = True)

# Extract data and labels from the DataFrame
data1 = data.iloc[:,2].values.tolist()
label = data.iloc[:,0].values.tolist()
labels = data['business_service'].unique().tolist()

pdf.setFont("Times-Roman", 10)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(290, 240, "Top Problems with Linked Incidents")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 90
bc.y = 30
bc.width = 350
bc.height = 170
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = label
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels

colors_list = []
variable = data['business_service']  # Replace 'your_variable' with the name of your variable
for value in variable:
    if value == 'Illustrations':
        bc.bars[0].fillColor=colors.blue  # Set the color for category1
    elif value == 'Network Illustration System':
        bc.bars[0].fillColor=colors.red  # Set the color for category2
    else:
        bc.bars[0].fillColor=colors.gray  # Set the default color for other categories

#bc.bars.fillColor = colors_list

# Create a legend
legend = Legend()
legend.x = 100
legend.y = 10
legend.alignment = 'right'
legend.fontSize = 8
legend.columnMaximum = 1  # Set the maximum number of columns for the legend
legend.deltay = 10  # Adjust the vertical spacing between legend items
legend.dxTextSpace = 10  # Adjust the horizontal spacing between legend items
legend.colorNamePairs = [(bc.bars[i].fillColor, labels[i]) for i in range(len(labels))]
# Add the bar chart and legend to the drawing
d.add(bc)
# Add a legend to the drawing
d.add(legend)


# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 10, 30)

data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


# In[14]:


#Create Page 5 (Active Problems by Service [NGIS/AMI]t)
pdf.showPage()
previously_taken_space = 0
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(185, 450, "Part 4: Problem Overview – NGIS | AMI")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].loc[(dataframes[4]['active']== True) & (dataframes[4]['business_service']== 'Illustrations')]
data = data[['number','business_service','related_incidents','u_jira_ticket','problem_state','sys_created_on','priority']]

data = data.rename(columns={'business_service' : 'service',
                            'related_incidents' : 'related \n incidents',
                            'u_jira_ticket' : 'u_jira \n ticket',
                            'problem_state' : 'problem state', 
                            'sys_created_on' : 'opened',
                              })

data = data.head(15)
data = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [60,50,50,50,100,70,50]  

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.black)
pdf.drawCentredString(150, 425, "Active Problems by Service [NGIS/AMI]")
previously_taken_space = 500 - 425

# Create the table from the data
t = Table(data,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 10),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), colors.lightblue),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

# Calculating displacement from top
row_space = len(data) * 25 # number of row * space per row
total_space_taken = row_space + previously_taken_space

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 50) # table at right side


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


# In[15]:


#Create Page 6 (Active Problems by Service [NIS/EB/QE/IFRP])
pdf.showPage()
previously_taken_space = 0

pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(212, 450, "Part 5: Problem Overview – NIS | EB | QE | IFRP")
pdf.line(50, 445, width-50, 445)

data = dataframes[4].loc[(dataframes[4]['active']== True) & (dataframes[4]['business_service'] != 'Illustrations')]
data = data[['number','business_service','related_incidents','u_jira_ticket','problem_state','sys_created_on','priority']]

data = data.rename(columns={'business_service' : 'service',
                            'related_incidents' : 'related \n incidents',
                            'u_jira_ticket' : 'u_jira \n ticket',
                            'problem_state' : 'problem state', 
                            'sys_created_on' : 'opened',
                              })

data = data.head(15)
data = [list(data.columns)] + data.values.tolist()

# Set the width for each column
column_widths = [70,80,40,40,85,65,50]  

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.black)
pdf.drawCentredString(167, 425, "Active Problems by Service [NIS/EB/QE/IFRP]")
previously_taken_space = 500-425
# Create the table from the data
t = Table(data,
         colWidths=column_widths)

# Define the style for the table
table_style = TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.navy),  # Set the background color for the header row
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),  # Set the text color for the header row
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),  # Set the alignment of the cells to center
    ("VALIGN", (0, 0), (-1, 1), "MIDDLE"),  # Cell vertical alignment
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),  # Set the font for the header row
    ("FONTSIZE", (0, 0), (-1, 0), 10),  # Set the font size for the header row
    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),  # Set the bottom padding for the header row
    ("BACKGROUND", (0, 1), (-1, -1), colors.lightblue),  # Set the background color for the data rows
    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),  # Set the text color for the data rows
    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),  # Set the font for the data rows
    ("FONTSIZE", (0, 1), (-1, -1), 8),  # Set the font size for the data rows
    ("BOTTOMPADDING", (0, 1), (-1, -1), 8),  # Set the bottom padding for the data rows
    ("BOX", (0, 0), (-1, -1), 1, "black"),  # Add borders to all cells
    ("ARROW", (0, 0), (0, -1), 10, 1, "black")  # Add an arrow to the
])

# Apply the table style to the table
t.setStyle(table_style)

# Calculating displacement from top
row_space = len(data) * 25 # number of row * space per row
total_space_taken = row_space + previously_taken_space

t.wrapOn(pdf, width, height)     
t.drawOn(pdf,50, 500-total_space_taken) # table at right side


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 30)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 400, "Aging Problems > 30 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 260
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 8  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart and legend to the drawing
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


data = dataframes[4][dataframes[4]['active']== True]
data.loc[:,'sys_created_on'] = pd.to_datetime(data['sys_created_on'])
data.loc[:,'Days'] = (datetime.now() - data['sys_created_on'])
data = data.loc[data['Days'] >= timedelta(days = 90)]
data = data.groupby(['business_service']).count()['number']

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 8)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(600, 250, "Aging Problems > 90 days")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = HorizontalBarChart()
bc.x = 270
bc.y = 115
bc.width = 120
bc.height = 100
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5
bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 50
bc.categoryAxis.labels.fontSize = 8
bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables
bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars
#bc.categoryAxis.style = 'stacked'
bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 7  # Set the font size of the bar labels
bc.bars[0].fillColor = colors.green

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 280, 30)


# In[16]:


#Create Page 7 (Problem Overview)
pdf.showPage()
pdf.setFont("Times-Roman", 16)
pdf.setFillColor(colors.navy)
pdf.drawCentredString(140, 450, "Part 6: Problem Overview")
pdf.line(50, 445, width-50, 445)

#sorting data in descending order
data = dataframes[4].groupby(['priority']).count()['sys_created_on']
data = data.sort_values(ascending = False)

# Extract data and labels from the DataFrame
data1 = data.values.tolist()
labels = data.index.values.tolist()

pdf.setFont("Times-Roman", 12)
pdf.setFillColor(colors.blue)
pdf.drawCentredString(330, 410, "PX Open Problems by Priority")

# Create a drawing
d = Drawing(800, 800)  # width, height

# Create a bar chart
bc = VerticalBarChart()
bc.x = 70
bc.y = 50
bc.width = 450
bc.height = 300
bc.data = [data1]
#bc.strokeColor = colors.black
bc.groupSpacing = 10
bc.barSpacing = 2.5

bc.categoryAxis.categoryNames = labels
bc.categoryAxis.labels.angle = 0
bc.categoryAxis.labels.fontSize = 14

bc.valueAxis.valueMin = 0
bc.valueAxis.valueMax = max(data1)  # Set the maximum value based on the maximum values of both variables

bc.barLabels.nudge = 10  # Adjust the spacing between the bars and labels
bc.barLabels.boxAnchor = 'w'  # Align the labels to the west (left) side of the bars

bc.barLabelFormat = '%d'
bc.barLabels.nudge = 7
bc.barLabels.fontSize = 14  # Set the font size of the bar labels

#Assigning different color to each bar
for i in range(len(labels)):
    bc.bars[0,i].fillColor = colors.Color(.8-((1+i)/10),.2+(i/5),.4+(i/len(labels)),1)

# Add the bar chart 
d.add(bc)

# Wrap the drawing on the PDF canvas
d.wrapOn(pdf, width, height)

# Draw the drawing on the PDF canvas
d.drawOn(pdf, 70, 30)


# In[17]:


# Save and close the PDF
#pdf_form.updatePageFormFieldValues(pdf)
pdf.save()


# In[18]:


#Create Page 8 (2023 Support Initiatives & Goals)
# This page will be directly added by merging the last page of the template 

def merge_pdfs(pdf_list):
    output = PdfWriter()
    for pdf in pdf_list:
        input_pdf = PdfReader(open(pdf, "rb"))
        for page in range(len(input_pdf.pages)):
            output.add_page(input_pdf.pages[page])
    outputStream = open("governance_report_final.pdf", "wb")
    output.write(outputStream)
    outputStream.close()

pdf_list = ["governance_report.pdf", "last_page.pdf"]
merge_pdfs(pdf_list)

